#!/bin/bash
# make
# make parsertrace
# make url_parser
# make http_parser.o
# gcc -Wall -Wextra -O3 http_parser.o demo.c -o demo -g
# ./demo 

